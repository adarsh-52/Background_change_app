package com.example.bg_changer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
